import React from "react";
function JobDevView(){
    return <h1>招聘 - 开发招聘</h1>
}
export default JobDevView;