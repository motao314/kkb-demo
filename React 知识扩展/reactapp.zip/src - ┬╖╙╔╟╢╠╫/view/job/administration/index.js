import React from "react";
function JobAbministrationView(){
    return <h1>招聘 - 行政招聘</h1>
}
export default JobAbministrationView;