import React from "react";
function JobFinanceView(){
    return <h1>招聘 - 财务招聘</h1>
}
export default JobFinanceView;