import React from "react";
function JobTeachingView(){
    return <h1>招聘 - 教研招聘</h1>
}
export default JobTeachingView;