import React from "react";
function JobView(){
    return <h1>招聘首页</h1>
}
export default JobView;