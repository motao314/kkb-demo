import React from "react";
function JobPersonnelView(){
    return <h1>招聘 - 人事招聘</h1>
}
export default JobPersonnelView;