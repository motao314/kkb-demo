import React from "react";
function CourseAIView(){
    return <h1>课程 - AI课程</h1>
}
export default CourseAIView;