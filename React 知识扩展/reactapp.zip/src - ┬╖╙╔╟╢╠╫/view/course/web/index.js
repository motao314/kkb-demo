import React from "react";
function CourseWebView(){
    return <h1>课程 - Web课程</h1>
}
export default CourseWebView;