import React from "react";

function CourseIndexView(){
    return <h1>课程首页</h1>
}

export default CourseIndexView;