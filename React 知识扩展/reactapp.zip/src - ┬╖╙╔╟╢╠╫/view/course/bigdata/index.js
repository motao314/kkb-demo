import React from "react";
function CourseBigDataView(){
    return <h1>课程 - 大数据课程</h1>
}
export default CourseBigDataView;