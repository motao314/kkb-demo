import React from "react";
function CourseJavaView(){
    return <h1>课程 - Java课程</h1>
}
export default CourseJavaView;