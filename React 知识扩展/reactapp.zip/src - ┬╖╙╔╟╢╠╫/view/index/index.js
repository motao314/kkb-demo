import React from "react";

function IndexView(){
    return <h1>首页</h1>
}

export default IndexView;