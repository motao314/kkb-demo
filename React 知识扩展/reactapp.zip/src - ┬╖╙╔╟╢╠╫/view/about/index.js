import React from "react";
function AboutView(){
    return <h1>关于我们</h1>
}
export default AboutView;