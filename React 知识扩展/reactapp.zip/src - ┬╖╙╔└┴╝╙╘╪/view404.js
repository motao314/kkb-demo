import React from 'react';
function View404() {
  return (<h1>404</h1>);
}

export default  View404;
