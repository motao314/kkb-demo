import {createContext} from  "react";
const context = createContext();
const {Provider} = context;
export default context;
export {Provider};